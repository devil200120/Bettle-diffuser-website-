import React from 'react';
import Footer from '../components/Footer';

const AssemblyVideos = () => {
  return (
    <div>
      <div className="placeholder-content">
        <p>No content Here</p>
      </div>
      <Footer />
    </div>
  );
};

export default AssemblyVideos;
