import React from 'react';
import Footer from '../components/Footer';

const About = () => {
  return (
    <div>
      <div className="placeholder-content">
        <p>No content Here</p>
      </div>
      <Footer />
    </div>
  );
};

export default About;
